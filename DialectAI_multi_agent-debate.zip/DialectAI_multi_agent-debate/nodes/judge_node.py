import os
import re
from openai import OpenAI
from utils.logging_utils import log_node

def create_judge_node():
    """
    Reads the full debate transcript (state['history']), decides the winner,
    then prompts the LLM to write a concise summary + rationale.
    Returns {"winner": str, "summary": str}.
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    def node(state: dict) -> dict:
        history = state.get("history", [])

        # Build the judge-style prompt
        transcript = "\n".join(history)
        summary_prompt = (
            "You are an impartial judge of an 8-round debate between a Scientist and a Philosopher.\n\n"
            "Here is the debate transcript:\n"
            f"{transcript}\n\n"
            "Please write:\n"
            "  1) A brief summary (1–2 paragraphs) of the main points each side made.\n"
            "  2) A single-sentence rationale for your decision.\n"
            "  3) Explicitly state the winner as either 'Scientist', 'Philosopher', or 'Draw'.\n"
            "Format your output as:\n"
            "Summary: <...>\nRationale: <...>\nWinner: <Scientist|Philosopher|Draw>"
        )

        # Call OpenAI
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a formal debate judge."},
                {"role": "user",   "content": summary_prompt},
            ]
        )
        summary = resp.choices[0].message.content.strip()

        # Extract winner from model output using regex
        match = re.search(r"Winner:\s*(Scientist|Philosopher|Draw)", summary)
        winner = match.group(1) if match else "Draw"

        # Return the packaged verdict
        out = {"winner": winner, "summary": summary}
        log_node("Judge", state, out)
        return out

    return node

