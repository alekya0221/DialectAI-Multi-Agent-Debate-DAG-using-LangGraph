from utils.logging_utils import log_node

def create_user_input_node():
    """
    Prompts the user for a topic and initializes an empty history.
    Returns a callable node(state) -> new_state.
    """
    def node(state: dict) -> dict:
        topic = input("Enter topic for debate: ")
        out   = {"topic": topic, "history": []}
        log_node("UserInput", state, out)
        return out
    return node
