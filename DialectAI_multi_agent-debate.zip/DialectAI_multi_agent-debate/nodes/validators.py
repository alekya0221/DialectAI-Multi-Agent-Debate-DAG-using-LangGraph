def validate_turn(agent: str, round_num: int):
    if agent == "Scientist" and round_num % 2 == 0:
        raise ValueError("Out of turn for Scientist.")
    if agent == "Philosopher" and round_num % 2 == 1:
        raise ValueError("Out of turn for Philosopher.")

def check_duplicate(argument: str, context: set):
    if argument in context:
        raise ValueError("Duplicate argument detected.")
