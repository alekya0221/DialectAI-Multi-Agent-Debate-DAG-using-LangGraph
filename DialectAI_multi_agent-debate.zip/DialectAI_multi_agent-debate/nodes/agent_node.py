import os
from openai import OpenAI
from utils.logging_utils import log_node
from typing import Callable, Dict, List, Any

def create_agent_node(
    agent_name: str,
    memory: Callable[[Dict[str, Any]], Dict[str, Any]],
    stance: str
):
    """
    Builds a node(state) that:
      1) Calls memory(state) → ctx with keys:
           topic, history, my_history, opponent_last
      2) Builds a system+user prompt from ctx + stance
      3) Calls OpenAI chat
      4) Appends "[AgentName] reply" to the FULL history
      5) Logs and returns the new state
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    def build_messages(
        topic: str,
        my_history: List[str],
        opponent_last: str,
        system_prompt: str,
    ) -> List[Dict[str, str]]:
        msgs = [
            {"role": "system",    "content": system_prompt},
        ]
        if opponent_last:
            msgs.append({
                "role":    "assistant",
                "content": f"Opponent last said: “{opponent_last}”"
            })
        if my_history:
            msgs.append({
                "role":    "assistant",
                "content": "Your prior points:\n" + "\n".join(my_history)
            })
        msgs.append({
            "role":    "user",
            "content": "Please give your next concise, novel argument."
        })
        return msgs

    def node(state: Dict[str, Any]) -> Dict[str, Any]:
        # 1) Pull in only the slice this agent should see
        ctx           = memory(state)
        topic         = ctx["topic"]
        my_history    = ctx["my_history"]
        opponent_last = ctx["opponent_last"]
        # Use the original state['history'] for updating : writes back into the central state["history"] not               #Leaking full history into the agent context
        full_history  = state["history"] #this is for appending new turn

        # 2) Now build a dynamic system prompt with the actual topic
        system_prompt = (
            f"You are {agent_name}, arguing *{stance.upper()}* on the topic: \"{topic}\". "
            "Respond strictly with respect to this topic and address only the opponent’s last point."
        )

        # 3) Build the message sequence
        messages = build_messages(topic, my_history, opponent_last, system_prompt)

        # 4) Call the LLM
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages
        )
        raw   = resp.choices[0].message.content.strip()

        # 5) Clean up and punctuate
        argument = " ".join(raw.split())
        if not argument.endswith((".", "?", "!")):
            argument += "."

        # 6) Append to the full transcript
        entry     = f"[{agent_name}] {argument}"
        new_state = {
            "topic":   state["topic"],
            "history": full_history + [entry]
        }

        # 7) Log and return
        log_node(f"Agent({agent_name})", state, new_state)
        return new_state

    return node
