from utils.logging_utils import log_node

def memory_node(state: dict) -> dict:
    """
    Full-transcript memory node. Logs and returns the unchanged state
    so that your audit trail captures every step.
    """
    log_node("Memory", state, state)
    return state
