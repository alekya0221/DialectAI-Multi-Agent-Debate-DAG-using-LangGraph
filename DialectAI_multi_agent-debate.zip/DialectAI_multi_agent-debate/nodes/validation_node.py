from utils.logging_utils import log_node
from nodes.memory_node       import memory_node
from nodes.validators        import validate_turn, check_duplicate

def create_validate_node(agent_name: str):
    """
    1) Ensure the correct agent is speaking (no double‐turns).
    2) Prevent duplicate arguments.
    Always returns a pruned dict for the next node.
    """
    def node(state: dict) -> dict:
        # 1) Prune to {topic, history}
        pruned  = memory_node(state)
        history = pruned["history"]

        # 2) Turn‐order check
        round_num = len(history) + 1
        validate_turn(agent_name, round_num)

        # 3) No‐repeats check
        seen = set()
        for turn in history:
            check_duplicate(turn, seen)
            seen.add(turn)

        # 4) Log and pass along the *exact* pruned state
        log_node(f"Validate({agent_name})", pruned, pruned)
        return pruned

    return node
