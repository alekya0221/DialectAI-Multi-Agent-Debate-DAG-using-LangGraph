from graphviz import Digraph
import os

def generate_dag_diagram():
    g = Digraph("DebateDAG", format='png')
    g.attr(rankdir='LR')

    g.node("UserInput")
    for i in range(1, 9):
        g.node(f"Round{i}")
    g.node("Judge")

    g.edge("UserInput", "Round1")
    for i in range(1, 8):
        g.edge(f"Round{i}", f"Round{i+1}")
    g.edge("Round8", "Judge")

    # Save to persistent project directory
    output_path = os.path.expanduser("~/multi_agent_debate/dag_diagram")
    g.render(filename=output_path, view=False)

if __name__ == "__main__":
    generate_dag_diagram()
