from dotenv import load_dotenv
import os

load_dotenv(dotenv_path=".env", override=True)
key = os.getenv("OPENAI_API_KEY", "")
print("Key loaded:", key[:5] + "..." if key else "NOT FOUND")
