from pydantic import BaseModel, Field
from typing import List

class DebateState(BaseModel):
    """
    The only fields we carry between nodes:
      • topic:   the debate topic
      • history: list of “[AgentName] argument” entries
    Defaults let us seed with an empty dict.
    """
    topic: str         = ""
    history: List[str] = Field(default_factory=list)



