# main.py
import os
from utils.logging_utils      import init_logger, log_message
from nodes.user_input_node    import create_user_input_node
from nodes.memory_node        import memory_node
from nodes.validation_node    import create_validate_node
from nodes.agent_node         import create_agent_node
from nodes.judge_node         import create_judge_node

def memory_for(agent_name: str):
    """
    Returns a function that slices out:
      topic, history, my_history, opponent_last
    from the full state.
    """
    def mem(state: dict) -> dict:
        full      = state["history"]
        prefix    = f"[{agent_name}] "
        my_hist   = [t for t in full if t.startswith(prefix)]
        opp_last  = next((t for t in reversed(full)
                          if not t.startswith(prefix)), None)
        return {
            "topic":         state["topic"],
            "my_history":    my_hist,
            "opponent_last": opp_last,
        }
    return mem

def main():
    # –– 0) fresh log
    init_logger()

    # –– 1) prompt & initial state
    topic_node = create_user_input_node()
    state      = topic_node({})  # -> {"topic":…, "history":[]}

    print()
    print("Starting debate between Scientist and Philosopher...")
    print()

    # –– 2) debate rounds
    ROUNDS = 8
    AGENTS = [("Scientist","pro"), ("Philosopher","con")]

    for i in range(ROUNDS):
        name, stance = AGENTS[i % 2]

        # a) log full transcript
        state = memory_node(state)

        # b) validate turn & duplicates
        state = create_validate_node(name)(state)

        # c) call the agent
        agent = create_agent_node(
            agent_name=name,
            memory=memory_for(name),
            stance=stance,
        )
        state = agent(state)

        # d) print only the new line
        entry = state["history"][-1]   # "[Name] text"
        speaker, text = entry.split("] ", 1)
        speaker = speaker.lstrip("[")
        print(f"[Round {i+1}] {speaker}: {text}")

    # –– 3) judge once
    state   = memory_node(state)
    verdict = create_judge_node()(state)

    # –– 4) print summary + winner + rationale
    print()
    print("[Judge] Summary of debate:")

    lines = verdict["summary"].splitlines()
    section = None
    buffer = {"Summary": [], "Rationale": [], "Winner": []}

    for line in lines:
        if line.startswith("Summary:"):
            section = "Summary"
            buffer["Summary"].append(line[len("Summary:"):].strip())
        elif line.startswith("Rationale:"):
            section = "Rationale"
            buffer["Rationale"].append(line[len("Rationale:"):].strip())
        elif line.startswith("Winner:"):
            section = "Winner"
            buffer["Winner"].append(line[len("Winner:"):].strip())
        elif section:
            buffer[section].append(line.strip())

    # 1) Print summary section first
    print("Summary:", " ".join(buffer["Summary"]))

    # 2) Then print winner line
    print(f"[Judge] Winner: {''.join(buffer['Winner'])}")

    # 3) Finally print rationale
    print("Rationale:", " ".join(buffer["Rationale"]))

    # 4) Still log the winner (unchanged)
    log_message(f"[Judge] Winner: {verdict['winner']}")

if __name__ == "__main__":
    main()


