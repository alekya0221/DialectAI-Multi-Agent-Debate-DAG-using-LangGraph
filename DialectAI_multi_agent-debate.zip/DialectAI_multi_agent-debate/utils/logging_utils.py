import logging
import datetime

class DualTimeFormatter(logging.Formatter):
    """
    Adds UTC (Zulu) and local‐time (with offset) stamps to each record.
    """
    def format(self, record):
        # record.created is a POSIX timestamp
        dt_utc   = datetime.datetime.fromtimestamp(record.created, datetime.timezone.utc)
        dt_local = datetime.datetime.fromtimestamp(record.created)  # uses system tz

        record.utc_time   = dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        record.local_time = dt_local.strftime("%Y-%m-%dT%H:%M:%S%z")
        return super().format(record)

def init_logger():
    # 1) Configure the root logger to write a fresh file each run
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    # 2) File handler with dual‐time formatter
    fh = logging.FileHandler("debate_log.txt", mode="w")
    fmt = "[UTC:%(utc_time)s][Local:%(local_time)s] [%(levelname)s] %(message)s"
    fh.setFormatter(DualTimeFormatter(fmt=fmt))
    logger.addHandler(fh)

    # 3) Silence HTTP‐level chatter from the OpenAI client
    for lib in ("openai", "httpx", "urllib3"):
        logging.getLogger(lib).setLevel(logging.WARNING)

def log_message(message: str):
    """
    For standalone messages (e.g. Judge verdict).
    """
    logging.info(message)

def log_node(name: str, inputs: dict, outputs: dict):
    """
    Logs node IN/OUT, but skips no-op Memory/Validate calls.
    """
    if (name.startswith("Memory") or name.startswith("Validate")) and inputs == outputs:
        return

    logging.info(f"[{name}] IN:  {inputs}")
    logging.info(f"[{name}] OUT: {outputs}")
